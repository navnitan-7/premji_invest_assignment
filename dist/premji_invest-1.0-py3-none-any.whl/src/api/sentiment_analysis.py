import random

def sentiment_analysis():
    return random.random()