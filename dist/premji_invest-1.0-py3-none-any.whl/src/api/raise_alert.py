def raise_alert():
    print("Users Notified")